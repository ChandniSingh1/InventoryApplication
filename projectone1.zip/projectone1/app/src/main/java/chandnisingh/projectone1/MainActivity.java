package chandnisingh.projectone1;

import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import androidx.navigation.ui.AppBarConfiguration;
import androidx.navigation.ui.NavigationUI;

import com.google.android.material.bottomnavigation.BottomNavigationView;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    private EditText etUsername;
    private EditText etPassword;
    private Button loginButton;
    private Button addButton;
    private Button deleteButton;
    private Button updateButton;
    private Button editButton;
    private Button requestButton;
    private EditText dataEditText;
    private ArrayList<String> dataList;
    private ArrayAdapter<String> adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        etUsername = findViewById(R.id.etlemail);
        etPassword = findViewById(R.id.etlpwd);
        loginButton = findViewById(R.id.btnlogin);
        addButton = findViewById(R.id.addButton);
        deleteButton = findViewById(R.id.deleteButton);
        updateButton = findViewById(R.id.updateButton);
        editButton = findViewById(R.id.editButton);
        requestButton = findViewById(R.id.requestButton);
        dataEditText = findViewById(R.id.etData); // Assuming you have an EditText for data input
        dataListView = findViewById(R.id.dataListView); // Assuming you have a ListView to display data

        dataList = new ArrayList<>();
        adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, dataList);
        dataListView.setAdapter(adapter);

        // Handle login button click
        loginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Get the password entered by the user
                String enteredPassword = etPassword.getText().toString();
                if (authenticateUser(enteredPassword)) {
                    // Successful login, handle here
                } else {
                    // Incorrect password, show an error message
                    etPassword.setError("Incorrect password");
                }
            }
        });

        // Handle request button click
        requestButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Change the button text to "Request Accepted" when clicked
                requestButton.setText("Request Accepted");
            }
        });

        // Handle add button click
        addButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Get the text entered by the user
                String enteredData = dataEditText.getText().toString();
                if (!enteredData.isEmpty()) {
                    // Add the data to the list
                    dataList.add(enteredData);
                    adapter.notifyDataSetChanged(); // Update the ListView
                    Toast.makeText(MainActivity.this, "Data Added: " + enteredData, Toast.LENGTH_SHORT).show();
                    dataEditText.setText(""); // Clear the EditText
                } else {
                    Toast.makeText(MainActivity.this, "Please enter data to add", Toast.LENGTH_SHORT).show();
                }
            }
        });

        // Handle delete button click
        deleteButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Get the text entered by the user
                String enteredData = dataEditText.getText().toString();
                if (dataList.contains(enteredData)) {
                    dataList.remove(enteredData); // Remove data from the list
                    adapter.notifyDataSetChanged(); // Update the ListView
                    Toast.makeText(MainActivity.this, "Data Deleted: " + enteredData, Toast.LENGTH_SHORT).show();
                    dataEditText.setText(""); // Clear the EditText
                } else {
                    Toast.makeText(MainActivity.this, "Data not found for deletion", Toast.LENGTH_SHORT).show();
                }
            }
        });

        // Handle update button click
        updateButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String enteredData = dataEditText.getText().toString();
                if (dataList.contains(enteredData)) {
                    int index = dataList.indexOf(enteredData); // Find index of data
                    dataList.set(index, "Updated: " + enteredData); // Update data
                    adapter.notifyDataSetChanged(); // Update the ListView
                    Toast.makeText(MainActivity.this, "Data Updated: " + enteredData, Toast.LENGTH_SHORT).show();
                    dataEditText.setText(""); // Clear the EditText
                } else {
                    Toast.makeText(MainActivity.this, "Data not found for updating", Toast.LENGTH_SHORT).show();
                }
            }
        });

        // Handle edit button click
        editButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String enteredData = dataEditText.getText().toString();
                if (dataList.contains(enteredData)) {
                    int index = dataList.indexOf(enteredData);
                    String editedData = dataList.get(index) + " (Edited)";
                    dataList.set(index, editedData);
                    adapter.notifyDataSetChanged();
                    Toast.makeText(MainActivity.this, "Data Edited: " + editedData, Toast.LENGTH_SHORT).show();
                    dataEditText.setText(""); // Clear the EditText
                } else {
                    Toast.makeText(MainActivity.this, "Data not found for editing", Toast.LENGTH_SHORT).show();
                }
            }
        });

        // Handle user registration button click
        Button registerButton = findViewById(R.id.btnregister);
        registerButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Handle user registration here
                String name = etUsername.getText().toString();
                String password = etPassword.getText().toString();
                // Add code to register the user, e.g., send the data to a server or save it locally
                Toast.makeText(MainActivity.this, "Successful registration!", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private boolean authenticateUser(String enteredPassword) {
        return enteredPassword.equals("password"); // Replace with your authentication logic
    }
}
